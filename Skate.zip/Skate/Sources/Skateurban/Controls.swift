import SpriteKit
import UIKit

class Controls {
    func handleTouch(_ touches: Set<UITouch>, in scene: SKScene) {
        // Processa o toque para controlar o jogo, como acionar truques ou mudar a direção.
    }
}